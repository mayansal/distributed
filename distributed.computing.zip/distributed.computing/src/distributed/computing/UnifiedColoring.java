package distributed.computing;

public class UnifiedColoring {

	public UnifiedColoring(ColoringsGroup cG, Graph g) {
		// TODO Auto-generated constructor stub
	}

	public void printColoring() {
		// TODO Auto-generated method stub
		
	}

}
