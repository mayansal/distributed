package distributed.computing;

public class ColoringsGroup {

	public ColoringsGroup(Forest f) {
		// TODO Auto-generated constructor stub
	}

}
