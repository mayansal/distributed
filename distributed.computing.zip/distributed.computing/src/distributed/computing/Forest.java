package distributed.computing;

public class Forest {
	int delta;
	
	Forest(Graph G){
		delta = 1;
	}
	
	public int getDelta(){
		return delta;
	}
	
}
