package distributed.computing;

import java.util.Random;

public class Graph {

	int[][] adjacencyMatrix;
	int numberOfVertices;
	
	/*empty constructor (random)*/
	Graph(){
		adjacencyMatrix = buildRandomAdjacencyMatrix();
		numberOfVertices = adjacencyMatrix.length;
	}
	
	private static int[][] buildRandomAdjacencyMatrix() {	
		Random rand = new Random();
		int matrixSize = rand.nextInt(30) + 2;
		int[][] matrix = new int[matrixSize][matrixSize];
		int isNeighbour;
		
		for(int i=0; i<matrix.length; i++){
			matrix[i][i] = 0;
			
			for(int j=i+1; j<matrix.length; j++){
				boolean isEdge = rand.nextInt(100) < 50;
				if(isEdge)
					isNeighbour = 1;
				else
					isNeighbour = 0;
				matrix[i][j] = isNeighbour;
				matrix[j][i] = isNeighbour;
			}
		}
		return matrix;
	}

	public void printGraph() {
			int i, j;
			for(i=0; i<numberOfVertices; i++){
				for(j=0; j<numberOfVertices-1; j++)
					System.out.print(adjacencyMatrix[i][j]+",");
				System.out.print(adjacencyMatrix[i][j]);
				System.out.println();
			}		
	}
	
}
