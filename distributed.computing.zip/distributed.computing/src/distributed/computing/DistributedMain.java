package distributed.computing;

public class DistributedMain {
	
	public static void main(String[] args) {
		
		Graph G = new Graph();
		G.printGraph();
		Forest F = new Forest(G);	
		ColoringsGroup CG = new ColoringsGroup(F);	
		UnifiedColoring UC = new UnifiedColoring(CG, G);
		UC.printColoring();	
	}
	
}
